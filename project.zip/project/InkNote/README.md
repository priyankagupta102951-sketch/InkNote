# InkNote — Native Android Tablet Note-Taking Application

InkNote is a production-grade, native Android tablet application engineered in Kotlin and Jetpack Compose. Inspired by modern digital paper workflows, InkNote offers handwritten digital notebook creation, vector-based stylus handwriting, paper template customization, and native PDF import, annotation, and export.

---

## 1. Key Features & Architecture

### A. Tablet-First UI & Original Branding
- **Aesthetic**: Warm white paper canvas (`#FAF8F5`), ink slate typography (`#1E293B`), and terracotta accent accents (`#E06D53`).
- **Responsive Layout**: Designed for Android tablets with dual landscape and portrait support, comfortable touch targets, and edge-to-edge support.
- **Library Screen**:
  - Top tablet app bar with search, filter chips (All Notes, Favorites, PDF Annotations), and grid/list view switcher.
  - Folder organization hierarchy with custom color badges.
  - Notebook book covers with dynamic spine styling, favorite star badges, and PDF indicators.
  - Contextual action menus: Rename, Duplicate, Move, and Delete.
- **Editor Studio**:
  - Full-screen drawing canvas supporting 60fps/120fps stylus input.
  - Floating and dockable `PenToolbar` with 8 quick-palette swatches, custom color picker, stroke thickness slider, and undo/redo buttons.
  - Slide-out `PageThumbnailsDrawer` for fast page navigation, reordering, duplication, and deletion.
  - Paper template picker: Ruled, Dotted, Grid, and Blank across Warm White, Cream, Soft Yellow, Mint, and Dark Slate paper tones.

### B. High-Performance Stylus Handwriting Engine
- **Vector Stroke Storage**: Stores strokes as structured vector data containing points, hardware pressure, timestamp, tilt, color hex, tool type, and bounding box.
- **Input Classifier & Palm Rejection**:
  - Distinguishes stylus input (`TOOL_TYPE_STYLUS` / `TOOL_TYPE_ERASER`) from finger gestures.
  - Two-finger gestures automatically trigger pan and pinch-to-zoom without leaving accidental pen marks.
  - Palm rejection filters large touch contact areas (`touchMajor > 120f`).
- **Smooth Splines & Dynamics**:
  - Catmull-Rom and quadratic Bezier curves eliminate jagged line segments.
  - Subpixel jitter filtering discards sensor noise while capturing high-frequency historical motion events (`MotionEvent.getHistoricalX/Y`).
  - Realistic pressure-to-thickness curves: fountain pen pressure expansion, pencil shading, and uniform highlighter chisel strokes.
- **True Stroke Eraser**:
  - Segment-to-point Euclidean distance mathematics with bounding box pruning for instant, lag-free stroke erasing.
- **Undo / Redo History**:
  - Memory-bounded action stack tracking stroke additions, deletions, and page clearing.

### C. Native PDF Import, Annotation & Vector Export
- **PDF Import**: Reads multipage PDFs via Android's `PdfRenderer`, extracting native page dimensions and generating matching canvas pages.
- **Hardware-Accelerated Rendering**: Caches high-resolution rendered PDF page bitmaps in an in-memory LRU cache to maintain smooth 120Hz panning.
- **Vector PDF Export**: Uses Android's native `android.graphics.pdf.PdfDocument` to re-compose original PDF pages (or paper templates) and render all vector ink annotations at full print resolution.
- **Share Sheet**: Integrated with `FileProvider` for sharing annotated PDFs via email, cloud drives, or messaging apps.

### D. Local Persistence & Resilience
- **Room Database**: Manages document metadata, folders, and page ordering.
- **Atomic File Persistence**: Structured stroke JSON arrays are stored in app-private storage (`filesDir/documents/{notebookId}/page_{pageId}_strokes.json`) using atomic temporary-file-write and rename operations, preventing file corruption on sudden app kills or battery exhaustion.
- **Autosave Engine**: Coroutine-based debounced autosaving with live status badge indicators ("Saved", "Saving…", "Unsaved").

---

## 2. Project Structure

```
InkNote/
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/
│       ├── main/
│       │   ├── AndroidManifest.xml
│       │   ├── java/com/inknote/app/
│       │   │   ├── InkNoteApp.kt
│       │   │   ├── MainActivity.kt
│       │   │   ├── data/
│       │   │   │   ├── local/
│       │   │   │   │   ├── Converters.kt
│       │   │   │   │   ├── FolderDao.kt
│       │   │   │   │   ├── InkNoteDatabase.kt
│       │   │   │   │   ├── NotebookDao.kt
│       │   │   │   │   ├── PageDao.kt
│       │   │   │   │   └── StrokeStorageManager.kt
│       │   │   │   ├── model/
│       │   │   │   │   ├── Entities.kt
│       │   │   │   │   ├── PaperTemplate.kt
│       │   │   │   │   └── Stroke.kt
│       │   │   │   └── repository/
│       │   │   │       └── NotebookRepository.kt
│       │   │   ├── engine/
│       │   │   │   ├── drawing/
│       │   │   │   │   ├── EraserEngine.kt
│       │   │   │   │   ├── InputClassifier.kt
│       │   │   │   │   ├── StrokeSmoother.kt
│       │   │   │   │   ├── TransformManager.kt
│       │   │   │   │   └── UndoRedoManager.kt
│       │   │   │   └── pdf/
│       │   │   │       ├── PdfExporter.kt
│       │   │   │       ├── PdfImporter.kt
│       │   │   │       └── PdfPageRenderer.kt
│       │   │   └── ui/
│       │   │       ├── components/
│       │   │       │   ├── NotebookCards.kt
│       │   │       │   ├── PageThumbnailsDrawer.kt
│       │   │       │   ├── PaperBackgroundRenderer.kt
│       │   │       │   ├── PaperCanvas.kt
│       │   │       │   ├── PenToolbar.kt
│       │   │       │   └── TemplateSelectorDialog.kt
│       │   │       ├── screens/
│       │   │       │   ├── EditorScreen.kt
│       │   │       │   └── LibraryScreen.kt
│       │   │       ├── theme/
│       │   │       │   ├── Color.kt
│       │   │       │   ├── Theme.kt
│       │   │       │   └── Type.kt
│       │   │       └── viewmodel/
│       │   │           ├── EditorViewModel.kt
│       │   │           └── LibraryViewModel.kt
│       │   └── res/
│       │       ├── drawable/
│       │       ├── mipmap-anydpi-v26/
│       │       ├── values/
│       │       │   ├── colors.xml
│       │       │   ├── strings.xml
│       │       │   └── themes.xml
│       │       └── xml/
│       │           └── file_paths.xml
│       └── test/java/com/inknote/app/
│           ├── EraserIntersectionTest.kt
│           ├── StrokeSmoothingTest.kt
│           ├── TransformManagerTest.kt
│           └── UndoRedoManagerTest.kt
├── build.gradle.kts
├── gradle.properties
├── gradlew
├── gradlew.bat
├── settings.gradle.kts
└── README.md
```

---

## 3. How to Build & Generate the APK

### Prerequisites
- **Android Studio**: Iguana (2023.2.1), Jellyfish (2023.3.1), Koala (2024.1.1), or Ladybug.
- **JDK**: Java 17 (recommended: Android Studio bundled OpenJDK 17).
- **Android SDK**: Compile SDK 34, Min SDK 26 (Android 8.0 Oreo or higher).

### Step-by-Step Build Instructions

1. **Open the Project in Android Studio**:
   - Launch Android Studio.
   - Click **Open** and select the `InkNote` directory.
   - Allow Gradle to sync dependencies automatically.

2. **Run Unit Tests**:
   - In Android Studio terminal or command line, run:
     ```bash
     ./gradlew test
     ```
   - This executes the unit tests verifying spline smoothing, eraser hit-testing, zoom/pan coordinate transformations, and undo/redo stacks.

3. **Build the Debug APK**:
   - Via Terminal:
     ```bash
     ./gradlew assembleDebug
     ```
   - Via Android Studio UI:
     - Open the **Build** menu at the top.
     - Select **Build Bundle(s) / APK(s)** > **Build APK(s)**.

4. **Locate the Generated APK**:
   - The compiled debug APK will be created at:
     ```
     app/build/outputs/apk/debug/app-debug.apk
     ```

5. **Install on an Android Tablet**:
   - **Via ADB**:
     ```bash
     adb install -r app/build/outputs/apk/debug/app-debug.apk
     ```
   - **Direct Sideloading**:
     - Transfer `app-debug.apk` to your tablet via USB cable, Google Drive, or local file sharing.
     - Open the tablet's Files app, tap the APK, and enable "Install from Unknown Sources" if prompted.

6. **Release APK & Signing (Production)**:
   - To build a release APK, create a signing keystore in Android Studio via **Build > Generate Signed Bundle / APK**.
   - Configure the `signingConfigs` block in `app/build.gradle.kts` and execute:
     ```bash
     ./gradlew assembleRelease
     ```

---

## 4. Environment Verification & Testing Disclosures

- **Algorithmic Math Verification**: Stroke jitter filtering, Bezier control point calculation, pressure-to-width curves, point-to-segment Euclidean distance calculations, and screen-to-canvas coordinate matrices have been mathematically validated.
- **Hardware Limitations**: Physical stylus pressure response curves, sub-millisecond digitizer latency, and palm rejection behaviors are configured according to standard Android `MotionEvent` and stylus APIs (`TOOL_TYPE_STYLUS`, `pressure`, `touchMajor`). Physical hardware testing requires an Android tablet with an active stylus (e.g., Samsung Galaxy Tab S-Pen or Google Pixel Tablet Stylus).
