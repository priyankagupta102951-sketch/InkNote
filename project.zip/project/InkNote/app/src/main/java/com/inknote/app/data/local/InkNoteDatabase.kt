package com.inknote.app.data.local

import android.content.Context
import androidx.room.*
import com.inknote.app.data.model.Folder
import com.inknote.app.data.model.Notebook
import com.inknote.app.data.model.Page

@Database(entities = [Notebook::class, Folder::class, Page::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class InkNoteDatabase : RoomDatabase() {
    abstract fun notebookDao(): NotebookDao
    abstract fun folderDao(): FolderDao
    abstract fun pageDao(): PageDao

    companion object {
        @Volatile private var INSTANCE: InkNoteDatabase? = null
        fun getDatabase(context: Context): InkNoteDatabase {
            return INSTANCE ?: synchronized(this) {
                val inst = Room.databaseBuilder(context.applicationContext, InkNoteDatabase::class.java, "inknote_db")
                    .fallbackToDestructiveMigration().build()
                INSTANCE = inst
                inst
            }
        }
    }
}
