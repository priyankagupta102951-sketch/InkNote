package com.inknote.app.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val TerracottaAccent = Color(0xFFE06D53)
val WarmPaper = Color(0xFFFAF8F5)
val InkNavy = Color(0xFF1E293B)

@Composable
fun InkNoteTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = InkNavy,
            secondary = TerracottaAccent,
            background = WarmPaper
        ),
        content = content
    )
}
