package com.inknote.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.inknote.app.data.model.Folder
import com.inknote.app.data.model.Notebook
import com.inknote.app.data.model.PaperColor
import com.inknote.app.data.model.PaperType
import com.inknote.app.ui.components.FolderCard
import com.inknote.app.ui.components.NotebookGridCard
import com.inknote.app.ui.theme.TerracottaAccent
import com.inknote.app.ui.theme.WarmPaper
import com.inknote.app.ui.viewmodel.LibraryFilter
import com.inknote.app.ui.viewmodel.LibraryViewModel

val CoverColors = listOf(
    "#2C3E50", // Midnight Blue
    "#E06D53", // Terracotta
    "#5B8266", // Sage Green
    "#D99B26", // Warm Ochre
    "#7E57C2", // Muted Violet
    "#34495E", // Slate Charcoal
    "#C0392B"  // Crimson
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    viewModel: LibraryViewModel,
    onOpenNotebook: (String) -> Unit
) {
    val notebooks by viewModel.notebooks.collectAsState()
    val folders by viewModel.folders.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val activeFilter by viewModel.activeFilter.collectAsState()
    val isGridView by viewModel.isGridView.collectAsState()
    val currentFolderId by viewModel.currentFolderId.collectAsState()

    var showCreateNotebookDialog by remember { mutableStateOf(false) }
    var showCreateFolderDialog by remember { mutableStateOf(false) }
    var notebookToRename by remember { mutableStateOf<Notebook?>(null) }
    var renameText by remember { mutableStateOf("") }

    val pdfPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { viewModel.importPdf(it) { notebookId -> onOpenNotebook(notebookId) } }
    }

    Scaffold(
        containerColor = WarmPaper,
        floatingActionButton = {
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // Import PDF FAB
                FloatingActionButton(
                    onClick = { pdfPickerLauncher.launch("application/pdf") },
                    containerColor = Color(0xFFC0392B),
                    contentColor = Color.White,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.shadow(4.dp, RoundedCornerShape(16.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = "Import PDF")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Import PDF", fontWeight = FontWeight.SemiBold)
                    }
                }

                // New Notebook FAB
                FloatingActionButton(
                    onClick = { showCreateNotebookDialog = true },
                    containerColor = TerracottaAccent,
                    contentColor = Color.White,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.shadow(6.dp, RoundedCornerShape(16.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "New Notebook")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("New Notebook", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 24.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // 1. Top Tablet App Bar: Logo + Search + Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(TerracottaAccent),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("IN", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "InkNote",
                        style = MaterialTheme.typography.headlineMedium,
                        color = Color(0xFF1E293B)
                    )
                }

                // Tablet Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    placeholder = { Text("Search notebooks, PDFs, tags…", color = Color(0xFF94A3B8)) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF718096)) },
                    singleLine = true,
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier
                        .width(360.dp)
                        .height(50.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedBorderColor = TerracottaAccent,
                        unfocusedBorderColor = Color(0xFFE2DDD5)
                    )
                )

                // View Toggle & New Folder
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { showCreateFolderDialog = true }) {
                        Icon(Icons.Default.CreateNewFolder, contentDescription = "New Folder", tint = Color(0xFF1E293B))
                    }
                    IconButton(onClick = { viewModel.toggleViewMode() }) {
                        Icon(
                            imageVector = if (isGridView) Icons.Default.ViewList else Icons.Default.GridView,
                            contentDescription = "Toggle View",
                            tint = Color(0xFF1E293B)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 2. Filter Chips & Breadcrumbs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = activeFilter == LibraryFilter.ALL,
                        onClick = { viewModel.setFilter(LibraryFilter.ALL) },
                        label = { Text("All Notes") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = TerracottaAccent,
                            selectedLabelColor = Color.White
                        )
                    )
                    FilterChip(
                        selected = activeFilter == LibraryFilter.FAVORITES,
                        onClick = { viewModel.setFilter(LibraryFilter.FAVORITES) },
                        label = { Text("Favorites") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = TerracottaAccent,
                            selectedLabelColor = Color.White
                        )
                    )
                    FilterChip(
                        selected = activeFilter == LibraryFilter.PDFS,
                        onClick = { viewModel.setFilter(LibraryFilter.PDFS) },
                        label = { Text("PDF Annotations") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = TerracottaAccent,
                            selectedLabelColor = Color.White
                        )
                    )
                }

                if (currentFolderId != null) {
                    TextButton(onClick = { viewModel.setFolder(null) }) {
                        Icon(Icons.Default.Home, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Root Library")
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3. Folders Row (if any)
            if (folders.isNotEmpty() && currentFolderId == null) {
                Text(
                    text = "Folders",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color(0xFF718096)
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    items(folders) { folder ->
                        FolderCard(
                            folder = folder,
                            onClick = { viewModel.setFolder(folder.id) },
                            onDelete = { viewModel.deleteFolder(folder) }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // 4. Notebooks Grid / Empty state
            if (notebooks.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 60.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.Description,
                            contentDescription = null,
                            modifier = Modifier.size(64.dp),
                            tint = Color(0xFFD4CEBF)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "No notebooks found",
                            style = MaterialTheme.typography.headlineSmall,
                            color = Color(0xFF1E293B)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Tap '+ New Notebook' or '+ Import PDF' to start writing",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFF718096)
                        )
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 200.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(bottom = 96.dp)
                ) {
                    items(notebooks) { notebook ->
                        NotebookGridCard(
                            notebook = notebook,
                            onClick = { onOpenNotebook(notebook.id) },
                            onToggleFavorite = { viewModel.toggleFavorite(notebook) },
                            onRename = {
                                notebookToRename = notebook
                                renameText = notebook.title
                            },
                            onDuplicate = { viewModel.duplicateNotebook(notebook) },
                            onDelete = { viewModel.deleteNotebook(notebook) }
                        )
                    }
                }
            }
        }
    }

    // Dialog: Create Notebook
    if (showCreateNotebookDialog) {
        CreateNotebookDialog(
            onDismiss = { showCreateNotebookDialog = false },
            onConfirm = { title, paperType, paperColor, coverColor ->
                viewModel.createNotebook(title, paperType, paperColor, coverColor) { id ->
                    showCreateNotebookDialog = false
                    onOpenNotebook(id)
                }
            }
        )
    }

    // Dialog: Create Folder
    if (showCreateFolderDialog) {
        var folderName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCreateFolderDialog = false },
            title = { Text("New Folder") },
            text = {
                OutlinedTextField(
                    value = folderName,
                    onValueChange = { folderName = it },
                    placeholder = { Text("Folder name") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (folderName.isNotBlank()) {
                            viewModel.createFolder(folderName)
                            showCreateFolderDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TerracottaAccent)
                ) { Text("Create") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateFolderDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Dialog: Rename Notebook
    notebookToRename?.let { nb ->
        AlertDialog(
            onDismissRequest = { notebookToRename = null },
            title = { Text("Rename Notebook") },
            text = {
                OutlinedTextField(
                    value = renameText,
                    onValueChange = { renameText = it },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (renameText.isNotBlank()) {
                            viewModel.renameNotebook(nb, renameText)
                            notebookToRename = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TerracottaAccent)
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { notebookToRename = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun CreateNotebookDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, PaperType, PaperColor, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var selectedPaperType by remember { mutableStateOf(PaperType.RULED) }
    var selectedPaperColor by remember { mutableStateOf(PaperColor.WARM_WHITE) }
    var selectedCoverColor by remember { mutableStateOf(CoverColors[0]) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create New Notebook", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    placeholder = { Text("Notebook Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))
                Text("Cover Color", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CoverColors.forEach { hex ->
                        val isSelected = hex == selectedCoverColor
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(android.graphics.Color.parseColor(hex)))
                                .border(
                                    width = if (isSelected) 3.dp else 1.dp,
                                    color = if (isSelected) TerracottaAccent else Color(0x33000000),
                                    shape = CircleShape
                                )
                                .clickable { selectedCoverColor = hex }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text("Paper Template", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PaperType.values().forEach { type ->
                        val isSelected = type == selectedPaperType
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) TerracottaAccent.copy(alpha = 0.15f) else Color(0xFFF4EFEB))
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) TerracottaAccent else Color(0xFFD4CEBF),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable { selectedPaperType = type },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = type.name.lowercase().replaceFirstChar { it.uppercase() },
                                fontSize = 12.sp,
                                color = if (isSelected) TerracottaAccent else Color(0xFF1E293B)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(title, selectedPaperType, selectedPaperColor, selectedCoverColor) },
                colors = ButtonDefaults.buttonColors(containerColor = TerracottaAccent)
            ) { Text("Create Notebook") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
