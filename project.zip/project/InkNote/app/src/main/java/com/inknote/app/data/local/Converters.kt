package com.inknote.app.data.local

import androidx.room.TypeConverter
import com.inknote.app.data.model.PaperColor
import com.inknote.app.data.model.PaperType

class Converters {
    @TypeConverter fun fromPaperType(v: PaperType): String = v.name
    @TypeConverter fun toPaperType(v: String): PaperType = runCatching { PaperType.valueOf(v) }.getOrDefault(PaperType.RULED)
    @TypeConverter fun fromPaperColor(v: PaperColor): String = v.name
    @TypeConverter fun toPaperColor(v: String): PaperColor = runCatching { PaperColor.valueOf(v) }.getOrDefault(PaperColor.WARM_WHITE)
}
