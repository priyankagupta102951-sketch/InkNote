package com.inknote.app.data.repository

import com.inknote.app.data.local.InkNoteDatabase
import com.inknote.app.data.local.StrokeStorageManager
import com.inknote.app.data.model.*
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class NotebookRepository(
    private val db: InkNoteDatabase,
    private val storage: StrokeStorageManager
) {
    val allNotebooks: Flow<List<Notebook>> = db.notebookDao().getAllNotebooks()
    val favoriteNotebooks: Flow<List<Notebook>> = db.notebookDao().getFavoriteNotebooks()
    val rootFolders: Flow<List<Folder>> = db.folderDao().getRootFolders()

    fun getNotebooksInFolder(fId: String): Flow<List<Notebook>> = db.notebookDao().getNotebooksInFolder(fId)
    fun searchNotebooks(q: String): Flow<List<Notebook>> = db.notebookDao().searchNotebooks(q)
    suspend fun getNotebook(id: String): Notebook? = db.notebookDao().getNotebookById(id)
    fun getPagesForNotebook(nbId: String): Flow<List<Page>> = db.pageDao().getPagesForNotebook(nbId)

    suspend fun createNotebook(
        title: String,
        folderId: String? = null,
        paperType: PaperType = PaperType.RULED,
        paperColor: PaperColor = PaperColor.WARM_WHITE,
        coverColorHex: String = "#2C3E50",
        initialPages: Int = 1,
        pdfPath: String? = null
    ): Notebook {
        val id = UUID.randomUUID().toString()
        val nb = Notebook(
            id = id, title = title, folderId = folderId,
            coverColorHex = coverColorHex, defaultPaperType = paperType,
            defaultPaperColor = paperColor, pageCount = initialPages,
            pdfSourcePath = pdfPath
        )
        db.notebookDao().insertNotebook(nb)
        val pages = (0 until initialPages).map { idx ->
            Page(id = UUID.randomUUID().toString(), notebookId = id, pageIndex = idx, paperType = paperType, paperColor = paperColor, pdfPageIndex = if (pdfPath != null) idx else null)
        }
        db.pageDao().insertPages(pages)
        return nb
    }

    suspend fun addPage(notebookId: String, afterIndex: Int, paperType: PaperType, paperColor: PaperColor): Page {
        val current = db.pageDao().getPagesListForNotebook(notebookId)
        val newPage = Page(id = UUID.randomUUID().toString(), notebookId = notebookId, pageIndex = afterIndex + 1, paperType = paperType, paperColor = paperColor)
        val shifted = current.map { if (it.pageIndex > afterIndex) it.copy(pageIndex = it.pageIndex + 1) else it }
        db.pageDao().insertPages(shifted)
        db.pageDao().insertPage(newPage)
        db.notebookDao().updatePageCount(notebookId, current.size + 1)
        return newPage
    }

    suspend fun updatePageTemplate(page: Page, paperType: PaperType, paperColor: PaperColor) {
        db.pageDao().updatePage(page.copy(paperType = paperType, paperColor = paperColor))
    }

    suspend fun deletePage(notebookId: String, page: Page): Boolean {
        val current = db.pageDao().getPagesListForNotebook(notebookId)
        if (current.size <= 1) return false
        db.pageDao().deletePage(page)
        val remaining = current.filter { it.id != page.id }.mapIndexed { idx, p -> p.copy(pageIndex = idx) }
        db.pageDao().insertPages(remaining)
        db.notebookDao().updatePageCount(notebookId, remaining.size)
        return true
    }

    suspend fun deleteNotebook(nb: Notebook) {
        db.notebookDao().deleteNotebook(nb)
        storage.deleteNotebookDir(nb.id)
    }

    suspend fun toggleFavorite(nb: Notebook) = db.notebookDao().updateFavorite(nb.id, !nb.isFavorite)
    suspend fun renameNotebook(id: String, title: String) = db.notebookDao().renameNotebook(id, title)
    suspend fun createFolder(name: String) = db.folderDao().insertFolder(Folder(name = name))
    suspend fun deleteFolder(f: Folder) = db.folderDao().deleteFolder(f)

    suspend fun saveStrokes(nbId: String, pageId: String, strokes: List<Stroke>): Boolean = storage.saveStrokes(nbId, pageId, strokes)
    suspend fun loadStrokes(nbId: String, pageId: String): List<Stroke> = storage.loadStrokes(nbId, pageId)
}
