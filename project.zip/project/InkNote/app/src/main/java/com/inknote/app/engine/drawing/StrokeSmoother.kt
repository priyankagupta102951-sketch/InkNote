package com.inknote.app.engine.drawing

import com.inknote.app.data.model.StrokePoint
import com.inknote.app.data.model.ToolType
import kotlin.math.sqrt

/**
 * Handles spline smoothing, jitter filtering, and dynamic stroke width calculations
 * based on stylus hardware pressure and stroke velocity.
 */
object StrokeSmoother {

    private const val MIN_DISTANCE_THRESHOLD = 2.0f // Minimum pixel distance between captured points

    /**
     * Filters out sub-pixel jitter points to optimize render performance and memory.
     */
    fun shouldAddPoint(lastPoint: StrokePoint?, newX: Float, newY: Float): Boolean {
        if (lastPoint == null) return true
        val dx = newX - lastPoint.x
        val dy = newY - lastPoint.y
        return (dx * dx + dy * dy) >= (MIN_DISTANCE_THRESHOLD * MIN_DISTANCE_THRESHOLD)
    }

    /**
     * Calculates the rendered stroke width at a point based on tool type, base width,
     * hardware pressure (0.0f - 1.0f), and velocity damping.
     */
    fun calculateDynamicWidth(
        toolType: ToolType,
        baseWidth: Float,
        pressure: Float,
        velocity: Float = 0f
    ): Float {
        return when (toolType) {
            ToolType.PEN -> {
                // Natural fountain pen dynamics: pressure expands stroke, high speed slightly tapers
                val clampedPressure = pressure.coerceIn(0.15f, 1.5f)
                val pressureFactor = 0.5f + (clampedPressure * 0.75f)
                val velocityDamping = (1.0f - (velocity * 0.05f)).coerceIn(0.7f, 1.0f)
                (baseWidth * pressureFactor * velocityDamping).coerceIn(baseWidth * 0.35f, baseWidth * 2.2f)
            }
            ToolType.PENCIL -> {
                // Pencil responsiveness: subtle texture variation
                val clampedPressure = pressure.coerceIn(0.2f, 1.2f)
                (baseWidth * (0.6f + clampedPressure * 0.5f)).coerceIn(baseWidth * 0.5f, baseWidth * 1.5f)
            }
            ToolType.HIGHLIGHTER -> {
                // Highlighters maintain uniform wide chisel or rounded width
                baseWidth
            }
            ToolType.ERASER -> {
                baseWidth
            }
        }
    }

    /**
     * Generates smooth quadratic Bezier control points between raw input points.
     * Returns a list of midpoint tuples (midX, midY) representing curve control targets.
     */
    fun calculateMidpoints(points: List<StrokePoint>): List<Pair<Float, Float>> {
        if (points.size < 2) return emptyList()
        val midpoints = ArrayList<Pair<Float, Float>>(points.size - 1)
        for (i in 0 until points.size - 1) {
            val p1 = points[i]
            val p2 = points[i + 1]
            midpoints.add(Pair((p1.x + p2.x) / 2f, (p1.y + p2.y) / 2f))
        }
        return midpoints
    }
}
