package com.inknote.app.ui.screens

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Style
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.inknote.app.data.model.SaveStatus
import com.inknote.app.ui.components.PageThumbnailsDrawer
import com.inknote.app.ui.components.PaperCanvas
import com.inknote.app.ui.components.PenToolbar
import com.inknote.app.ui.components.TemplateSelectorDialog
import com.inknote.app.ui.theme.TerracottaAccent
import com.inknote.app.ui.viewmodel.EditorViewModel
import kotlinx.coroutines.launch

@Composable
fun EditorScreen(
    viewModel: EditorViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val notebook by viewModel.notebook.collectAsState()
    val pages by viewModel.pages.collectAsState()
    val currentPageIndex by viewModel.currentPageIndex.collectAsState()
    val strokes by viewModel.strokes.collectAsState()
    val saveStatus by viewModel.saveStatus.collectAsState()
    val currentTool by viewModel.currentTool.collectAsState()
    val currentColorHex by viewModel.currentColorHex.collectAsState()
    val currentStrokeWidth by viewModel.currentStrokeWidth.collectAsState()
    val canUndo by viewModel.canUndo.collectAsState()
    val canRedo by viewModel.canRedo.collectAsState()
    val pdfBitmap by viewModel.pdfPageBitmap.collectAsState()

    var showThumbnailsDrawer by remember { mutableStateOf(false) }
    var showTemplateSelector by remember { mutableStateOf(false) }
    var isExporting by remember { mutableStateOf(false) }

    val currentPage = pages.getOrNull(currentPageIndex)

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .shadow(2.dp),
                color = Color(0xFFFAF8F5)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Left: Back button + Title
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color(0xFF1E293B))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = notebook?.title ?: "InkNote",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF1E293B)
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        // Save status pill
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    when (saveStatus) {
                                        SaveStatus.SAVED -> Color(0xFFDCFCE7)
                                        SaveStatus.SAVING -> Color(0xFFFEF3C7)
                                        SaveStatus.UNSAVED -> Color(0xFFFFEDD5)
                                        SaveStatus.ERROR -> Color(0xFFFEE2E2)
                                    }
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = when (saveStatus) {
                                    SaveStatus.SAVED -> "Saved"
                                    SaveStatus.SAVING -> "Saving…"
                                    SaveStatus.UNSAVED -> "Unsaved"
                                    SaveStatus.ERROR -> "Sync Error"
                                },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = when (saveStatus) {
                                    SaveStatus.SAVED -> Color(0xFF166534)
                                    SaveStatus.SAVING -> Color(0xFF92400E)
                                    SaveStatus.UNSAVED -> Color(0xFF9A3412)
                                    SaveStatus.ERROR -> Color(0xFF991B1B)
                                }
                            )
                        }
                    }

                    // Center: Page navigation controls
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        IconButton(
                            onClick = { viewModel.selectPage(currentPageIndex - 1) },
                            enabled = currentPageIndex > 0
                        ) {
                            Icon(Icons.Default.ChevronLeft, contentDescription = "Previous Page")
                        }

                        Text(
                            text = "Page ${currentPageIndex + 1} of ${pages.size.coerceAtLeast(1)}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF1E293B)
                        )

                        IconButton(
                            onClick = { viewModel.selectPage(currentPageIndex + 1) },
                            enabled = currentPageIndex < pages.size - 1
                        ) {
                            Icon(Icons.Default.ChevronRight, contentDescription = "Next Page")
                        }
                    }

                    // Right: Drawer toggle, Template selector, PDF Export
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { showTemplateSelector = true }) {
                            Icon(Icons.Default.Style, contentDescription = "Paper Template", tint = Color(0xFF2C3E50))
                        }

                        IconButton(onClick = { showThumbnailsDrawer = !showThumbnailsDrawer }) {
                            Icon(Icons.Default.Layers, contentDescription = "Page Drawer", tint = Color(0xFF2C3E50))
                        }

                        IconButton(
                            onClick = {
                                isExporting = true
                                viewModel.exportToPdf { file ->
                                    isExporting = false
                                    if (file != null && file.exists()) {
                                        coroutineScope.launch {
                                            snackbarHostState.showSnackbar("PDF Exported: ${file.name}")
                                        }
                                        try {
                                            val uri = FileProvider.getUriForFile(
                                                context,
                                                "${context.packageName}.fileprovider",
                                                file
                                            )
                                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                                type = "application/pdf"
                                                putExtra(Intent.EXTRA_STREAM, uri)
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(Intent.createChooser(shareIntent, "Share Annotated PDF"))
                                        } catch (e: Exception) {
                                            e.printStackTrace()
                                        }
                                    }
                                }
                            },
                            enabled = !isExporting
                        ) {
                            if (isExporting) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = "Export PDF", tint = Color(0xFFC0392B))
                            }
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Main Drawing Canvas
            if (currentPage != null) {
                PaperCanvas(
                    page = currentPage,
                    pdfBitmap = pdfBitmap,
                    strokes = strokes,
                    currentTool = currentTool,
                    currentColorHex = currentColorHex,
                    currentStrokeWidth = currentStrokeWidth,
                    transformManager = viewModel.transformManager,
                    eraserEngine = viewModel.eraserEngine,
                    onStrokeAdded = { viewModel.addStroke(it) },
                    onStrokesErased = { viewModel.eraseStrokes(it) },
                    onTransformChanged = { /* Redraw triggered via Compose state */ }
                )
            }

            // Floating Pen Toolbar at top center
            PenToolbar(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 16.dp),
                selectedTool = currentTool,
                selectedColorHex = currentColorHex,
                strokeWidth = currentStrokeWidth,
                canUndo = canUndo,
                canRedo = canRedo,
                onToolSelected = { viewModel.setTool(it) },
                onColorSelected = { viewModel.setColor(it) },
                onStrokeWidthChanged = { viewModel.setStrokeWidth(it) },
                onUndoClick = { viewModel.undo() },
                onRedoClick = { viewModel.redo() }
            )

            // Side Thumbnail Drawer
            AnimatedVisibility(
                visible = showThumbnailsDrawer,
                enter = slideInHorizontally(initialOffsetX = { it }),
                exit = slideOutHorizontally(targetOffsetX = { it }),
                modifier = Modifier.align(Alignment.CenterEnd)
            ) {
                PageThumbnailsDrawer(
                    pages = pages,
                    currentPageIndex = currentPageIndex,
                    onPageSelected = {
                        viewModel.selectPage(it)
                        showThumbnailsDrawer = false
                    },
                    onAddPage = { viewModel.addNewPage() },
                    onDuplicatePage = { viewModel.duplicatePage(it) },
                    onDeletePage = { viewModel.deleteCurrentPage() },
                    onClose = { showThumbnailsDrawer = false }
                )
            }
        }
    }

    if (showTemplateSelector && currentPage != null) {
        TemplateSelectorDialog(
            initialPaperType = currentPage.paperType,
            initialPaperColor = currentPage.paperColor,
            onDismiss = { showTemplateSelector = false },
            onConfirm = { paperType, paperColor ->
                viewModel.updatePageTemplate(paperType, paperColor)
                showTemplateSelector = false
            }
        )
    }
}
