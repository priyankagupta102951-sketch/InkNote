package com.inknote.app.engine.drawing

import android.view.MotionEvent

enum class InputMode {
    DRAWING,
    GESTURE_PAN_ZOOM,
    IGNORE
}

/**
 * Handles stylus hardware identification, palm rejection heuristics,
 * and seamless dual-finger pinch/pan gesture detection.
 */
object InputClassifier {

    /**
     * Determines whether an input motion event represents a dedicated stylus/pen.
     */
    fun isStylusEvent(event: MotionEvent): Boolean {
        val toolType = event.getToolType(0)
        return toolType == MotionEvent.TOOL_TYPE_STYLUS || toolType == MotionEvent.TOOL_TYPE_ERASER
    }

    /**
     * Evaluates incoming touch events:
     * - Stylus always draws with pressure
     * - 2 or more fingers trigger pinch-to-zoom and canvas panning
     * - Single finger draws if stylus-only mode is disabled, or pans if stylus-only mode is active
     */
    fun classifyMotion(
        event: MotionEvent,
        stylusOnlyDrawing: Boolean = false
    ): InputMode {
        val pointerCount = event.pointerCount

        if (pointerCount >= 2) {
            return InputMode.GESTURE_PAN_ZOOM
        }

        val isStylus = isStylusEvent(event)

        if (isStylus) {
            return InputMode.DRAWING
        }

        // Palm rejection heuristic: reject abnormally large touch contact areas (resting palm)
        val touchMajor = event.touchMajor
        if (touchMajor > 120f) {
            return InputMode.IGNORE
        }

        return if (stylusOnlyDrawing) {
            InputMode.GESTURE_PAN_ZOOM
        } else {
            InputMode.DRAWING
        }
    }
}
