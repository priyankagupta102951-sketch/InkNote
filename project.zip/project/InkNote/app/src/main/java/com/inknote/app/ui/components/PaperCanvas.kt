package com.inknote.app.ui.components

import android.graphics.Bitmap
import android.view.MotionEvent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke as ComposeStroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.input.pointer.pointerInteropFilter
import com.inknote.app.data.model.Page
import com.inknote.app.data.model.Stroke
import com.inknote.app.data.model.StrokePoint
import com.inknote.app.data.model.ToolType
import com.inknote.app.engine.drawing.EraserEngine
import com.inknote.app.engine.drawing.InputClassifier
import com.inknote.app.engine.drawing.InputMode
import com.inknote.app.engine.drawing.StrokeSmoother
import com.inknote.app.engine.drawing.TransformManager
import java.util.UUID

@Composable
fun PaperCanvas(
    modifier: Modifier = Modifier,
    page: Page,
    pdfBitmap: Bitmap? = null,
    strokes: List<Stroke>,
    currentTool: ToolType,
    currentColorHex: String,
    currentStrokeWidth: Float,
    transformManager: TransformManager,
    eraserEngine: EraserEngine,
    onStrokeAdded: (Stroke) -> Unit,
    onStrokesErased: (List<Stroke>) -> Unit,
    onTransformChanged: () -> Unit
) {
    // Points captured during the active ongoing stroke
    val activePoints = remember { mutableStateListOf<StrokePoint>() }
    val isActivelyDrawing = remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFE5E0D8))
            .pointerInteropFilter { motionEvent ->
                val pointerCount = motionEvent.pointerCount
                val action = motionEvent.actionMasked

                // Gesture handling for 2-finger zoom and pan
                if (pointerCount >= 2) {
                    if (isActivelyDrawing.value) {
                        isActivelyDrawing.value = false
                        activePoints.clear()
                    }
                    return@pointerInteropFilter false
                }

                val inputMode = InputClassifier.classifyMotion(motionEvent, stylusOnlyDrawing = false)
                if (inputMode == InputMode.IGNORE) {
                    return@pointerInteropFilter true
                }

                val screenX = motionEvent.x
                val screenY = motionEvent.y
                val canvasX = transformManager.screenToCanvasX(screenX)
                val canvasY = transformManager.screenToCanvasY(screenY)
                val pressure = if (motionEvent.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS) {
                    motionEvent.pressure.coerceIn(0.1f, 1.5f)
                } else 1.0f

                when (action) {
                    MotionEvent.ACTION_DOWN -> {
                        if (currentTool == ToolType.ERASER) {
                            val erased = eraserEngine.findStrokesToErase(strokes, canvasX, canvasY, currentStrokeWidth * 2f)
                            if (erased.isNotEmpty()) {
                                onStrokesErased(erased)
                            }
                        } else {
                            isActivelyDrawing.value = true
                            activePoints.clear()
                            activePoints.add(StrokePoint(canvasX, canvasY, pressure, System.currentTimeMillis()))
                        }
                        true
                    }

                    MotionEvent.ACTION_MOVE -> {
                        if (currentTool == ToolType.ERASER) {
                            val erased = eraserEngine.findStrokesToErase(strokes, canvasX, canvasY, currentStrokeWidth * 2f)
                            if (erased.isNotEmpty()) {
                                onStrokesErased(erased)
                            }
                        } else if (isActivelyDrawing.value) {
                            // Extract historical motion events for ultra-smooth stylus latency
                            val historySize = motionEvent.historySize
                            for (h in 0 until historySize) {
                                val hx = transformManager.screenToCanvasX(motionEvent.getHistoricalX(h))
                                val hy = transformManager.screenToCanvasY(motionEvent.getHistoricalY(h))
                                val hp = motionEvent.getHistoricalPressure(h).coerceIn(0.1f, 1.5f)
                                if (StrokeSmoother.shouldAddPoint(activePoints.lastOrNull(), hx, hy)) {
                                    activePoints.add(StrokePoint(hx, hy, hp, motionEvent.getHistoricalEventTime(h)))
                                }
                            }
                            if (StrokeSmoother.shouldAddPoint(activePoints.lastOrNull(), canvasX, canvasY)) {
                                activePoints.add(StrokePoint(canvasX, canvasY, pressure, motionEvent.eventTime))
                            }
                        }
                        true
                    }

                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        if (isActivelyDrawing.value && activePoints.size >= 1) {
                            val finalPoints = activePoints.toList()
                            val stroke = Stroke(
                                id = UUID.randomUUID().toString(),
                                pageId = page.id,
                                points = if (finalPoints.size == 1) {
                                    // Single tap dot: duplicate point slightly to give stroke thickness
                                    listOf(finalPoints[0], finalPoints[0].copy(x = finalPoints[0].x + 0.5f, y = finalPoints[0].y + 0.5f))
                                } else finalPoints,
                                colorHex = currentColorHex,
                                width = StrokeSmoother.calculateDynamicWidth(currentTool, currentStrokeWidth, pressure),
                                toolType = currentTool
                            )
                            onStrokeAdded(stroke)
                        }
                        isActivelyDrawing.value = false
                        activePoints.clear()
                        true
                    }
                    else -> false
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val scale = transformManager.scale
            val panX = transformManager.panX
            val panY = transformManager.panY

            translate(left = panX, top = panY) {
                scale(scale = scale, pivot = Offset.Zero) {
                    // 1. Draw page background (PDF page or Paper template)
                    if (pdfBitmap != null && !pdfBitmap.isRecycled) {
                        drawImage(image = pdfBitmap.asImageBitmap(), topLeft = Offset.Zero)
                    } else {
                        PaperBackgroundRenderer.drawPaper(
                            drawScope = this,
                            width = page.width,
                            height = page.height,
                            paperType = page.paperType,
                            paperColor = page.paperColor
                        )
                    }

                    // 2. Render committed strokes
                    for (stroke in strokes) {
                        drawInkStroke(stroke)
                    }

                    // 3. Render live active stroke
                    if (isActivelyDrawing.value && activePoints.size >= 2) {
                        val activeStroke = Stroke(
                            pageId = page.id,
                            points = activePoints.toList(),
                            colorHex = currentColorHex,
                            width = StrokeSmoother.calculateDynamicWidth(currentTool, currentStrokeWidth, activePoints.last().pressure),
                            toolType = currentTool
                        )
                        drawInkStroke(activeStroke)
                    }
                }
            }
        }
    }
}

private fun DrawScope.drawInkStroke(stroke: Stroke) {
    if (stroke.points.size < 2) return

    val colorInt = runCatching { android.graphics.Color.parseColor(stroke.colorHex) }.getOrDefault(android.graphics.Color.BLACK)
    val baseColor = Color(colorInt)

    val (renderColor, blendMode) = when (stroke.toolType) {
        ToolType.HIGHLIGHTER -> Pair(baseColor.copy(alpha = 0.35f), BlendMode.Multiply)
        ToolType.PENCIL -> Pair(baseColor.copy(alpha = 0.75f), BlendMode.SrcOver)
        else -> Pair(baseColor, BlendMode.SrcOver)
    }

    val path = Path().apply {
        val first = stroke.points.first()
        moveTo(first.x, first.y)

        for (i in 1 until stroke.points.size) {
            val p1 = stroke.points[i - 1]
            val p2 = stroke.points[i]
            val midX = (p1.x + p2.x) / 2f
            val midY = (p1.y + p2.y) / 2f
            quadraticBezierTo(p1.x, p1.y, midX, midY)
        }
        val last = stroke.points.last()
        lineTo(last.x, last.y)
    }

    drawPath(
        path = path,
        color = renderColor,
        blendMode = blendMode,
        style = ComposeStroke(
            width = stroke.width,
            cap = if (stroke.toolType == ToolType.HIGHLIGHTER) StrokeCap.Square else StrokeCap.Round,
            join = StrokeJoin.Round
        )
    )
}
