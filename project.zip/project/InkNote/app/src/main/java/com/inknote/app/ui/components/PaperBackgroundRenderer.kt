package com.inknote.app.ui.components

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.inknote.app.data.model.PaperColor
import com.inknote.app.data.model.PaperType

object PaperBackgroundRenderer {

    fun drawPaper(
        drawScope: DrawScope,
        width: Float,
        height: Float,
        paperType: PaperType,
        paperColor: PaperColor,
        isDarkTheme: Boolean = false
    ) {
        val bgColorHex = if (isDarkTheme && paperColor == PaperColor.WARM_WHITE) {
            paperColor.darkHex
        } else {
            paperColor.hex
        }
        val bgColor = Color(android.graphics.Color.parseColor(bgColorHex))
        val lineColor = if (isDarkTheme) Color(0xFF334155) else Color(0xFFD4CEBF)
        val dotColor = if (isDarkTheme) Color(0xFF475569) else Color(0xFFB5ADA0)

        // 1. Fill base paper surface
        drawScope.drawRect(
            color = bgColor,
            size = Size(width, height)
        )

        // 2. Draw pattern
        when (paperType) {
            PaperType.BLANK -> {
                // Clean paper
            }
            PaperType.RULED -> {
                val lineSpacing = 48f
                var y = 96f
                while (y < height) {
                    drawScope.drawLine(
                        color = lineColor,
                        start = Offset(0f, y),
                        end = Offset(width, y),
                        strokeWidth = 1.5f
                    )
                    y += lineSpacing
                }
            }
            PaperType.GRID -> {
                val gridSpacing = 40f
                var x = 0f
                while (x < width) {
                    drawScope.drawLine(
                        color = lineColor.copy(alpha = 0.7f),
                        start = Offset(x, 0f),
                        end = Offset(x, height),
                        strokeWidth = 1.0f
                    )
                    x += gridSpacing
                }
                var y = 0f
                while (y < height) {
                    drawScope.drawLine(
                        color = lineColor.copy(alpha = 0.7f),
                        start = Offset(0f, y),
                        end = Offset(width, y),
                        strokeWidth = 1.0f
                    )
                    y += gridSpacing
                }
            }
            PaperType.DOTTED -> {
                val dotSpacing = 36f
                var x = dotSpacing
                while (x < width) {
                    var y = dotSpacing
                    while (y < height) {
                        drawScope.drawCircle(
                            color = dotColor,
                            radius = 2.0f,
                            center = Offset(x, y)
                        )
                        y += dotSpacing
                    }
                    x += dotSpacing
                }
            }
        }
    }
}
