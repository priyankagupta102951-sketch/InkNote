package com.inknote.app.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FormatPaint
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.inknote.app.data.model.ToolType
import com.inknote.app.ui.theme.TerracottaAccent

val PaletteColors = listOf(
    "#1E293B", // Navy Black
    "#2563EB", // Royal Blue
    "#DC2626", // Crimson Red
    "#16A34A", // Emerald Green
    "#D97706", // Amber
    "#9333EA", // Purple
    "#E06D53", // Terracotta
    "#EAB308"  // Highlighter Yellow
)

val PresetWidths = listOf(2f, 4f, 8f, 16f, 28f)

@Composable
fun PenToolbar(
    modifier: Modifier = Modifier,
    selectedTool: ToolType,
    selectedColorHex: String,
    strokeWidth: Float,
    canUndo: Boolean,
    canRedo: Boolean,
    onToolSelected: (ToolType) -> Unit,
    onColorSelected: (String) -> Unit,
    onStrokeWidthChanged: (Float) -> Unit,
    onUndoClick: () -> Unit,
    onRedoClick: () -> Unit
) {
    var showColorPicker by remember { mutableStateOf(false) }
    var showWidthSlider by remember { mutableStateOf(false) }

    Surface(
        modifier = modifier
            .shadow(8.dp, RoundedCornerShape(24.dp))
            .border(1.dp, Color(0xFFE2DDD5), RoundedCornerShape(24.dp)),
        shape = RoundedCornerShape(24.dp),
        color = Color(0xFFFAF8F5).copy(alpha = 0.95f),
        tonalElevation = 6.dp
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Undo / Redo
                IconButton(onClick = onUndoClick, enabled = canUndo) {
                    Icon(
                        imageVector = Icons.Default.Undo,
                        contentDescription = "Undo",
                        tint = if (canUndo) Color(0xFF1E293B) else Color(0xFFB0A99F)
                    )
                }

                IconButton(onClick = onRedoClick, enabled = canRedo) {
                    Icon(
                        imageVector = Icons.Default.Redo,
                        contentDescription = "Redo",
                        tint = if (canRedo) Color(0xFF1E293B) else Color(0xFFB0A99F)
                    )
                }

                Spacer(modifier = Modifier.width(4.dp).height(24.dp).background(Color(0xFFE2DDD5)))

                // Tool selection buttons
                ToolButton(
                    icon = Icons.Default.Create,
                    title = "Pen",
                    isSelected = selectedTool == ToolType.PEN,
                    onClick = { onToolSelected(ToolType.PEN) }
                )

                ToolButton(
                    icon = Icons.Default.Edit,
                    title = "Pencil",
                    isSelected = selectedTool == ToolType.PENCIL,
                    onClick = { onToolSelected(ToolType.PENCIL) }
                )

                ToolButton(
                    icon = Icons.Default.FormatPaint,
                    title = "Highlighter",
                    isSelected = selectedTool == ToolType.HIGHLIGHTER,
                    onClick = { onToolSelected(ToolType.HIGHLIGHTER) }
                )

                ToolButton(
                    icon = Icons.Default.AutoAwesome,
                    title = "Eraser",
                    isSelected = selectedTool == ToolType.ERASER,
                    onClick = { onToolSelected(ToolType.ERASER) }
                )

                Spacer(modifier = Modifier.width(4.dp).height(24.dp).background(Color(0xFFE2DDD5)))

                // Color swatch button
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Color(android.graphics.Color.parseColor(selectedColorHex)))
                        .border(2.dp, if (showColorPicker) TerracottaAccent else Color(0xFFD4CEBF), CircleShape)
                        .clickable { showColorPicker = !showColorPicker }
                )

                // Stroke width indicator pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (showWidthSlider) Color(0xFFEAE3DA) else Color.Transparent)
                        .clickable { showWidthSlider = !showWidthSlider }
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${strokeWidth.toInt()}pt",
                        fontSize = 13.sp,
                        color = Color(0xFF1E293B),
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }

            // Expandable Color Picker Drawer
            AnimatedVisibility(visible = showColorPicker) {
                Row(
                    modifier = Modifier.padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    PaletteColors.forEach { hex ->
                        val color = Color(android.graphics.Color.parseColor(hex))
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(color)
                                .border(
                                    width = if (selectedColorHex == hex) 3.dp else 1.dp,
                                    color = if (selectedColorHex == hex) TerracottaAccent else Color(0x33000000),
                                    shape = CircleShape
                                )
                                .clickable {
                                    onColorSelected(hex)
                                    showColorPicker = false
                                }
                        )
                    }
                }
            }

            // Expandable Width Slider
            AnimatedVisibility(visible = showWidthSlider) {
                Row(
                    modifier = Modifier.padding(top = 8.dp, start = 8.dp, end = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Thickness", fontSize = 12.sp, color = Color(0xFF718096))
                    Slider(
                        value = strokeWidth,
                        onValueChange = onStrokeWidthChanged,
                        valueRange = 1f..40f,
                        modifier = Modifier.width(180.dp).padding(horizontal = 8.dp),
                        colors = SliderDefaults.colors(
                            thumbColor = TerracottaAccent,
                            activeTrackColor = TerracottaAccent
                        )
                    )
                    Text("${strokeWidth.toInt()}px", fontSize = 12.sp, color = Color(0xFF1E293B))
                }
            }
        }
    }
}

@Composable
private fun ToolButton(
    icon: ImageVector,
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) TerracottaAccent.copy(alpha = 0.15f) else Color.Transparent)
            .border(
                width = if (isSelected) 1.5.dp else 0.dp,
                color = if (isSelected) TerracottaAccent else Color.Transparent,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = if (isSelected) TerracottaAccent else Color(0xFF2C3E50),
            modifier = Modifier.size(22.dp)
        )
    }
}
