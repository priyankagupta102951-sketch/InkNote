package com.inknote.app.engine.drawing

import kotlin.math.max
import kotlin.math.min

/**
 * Manages 2D canvas transformations (zoom scale & pan offsets).
 * Translates touch coordinates from screen viewport to document canvas coordinates and vice versa.
 */
class TransformManager(
    val minScale: Float = 0.5f,
    val maxScale: Float = 4.0f
) {
    var scale: Float = 1.0f
        private set

    var panX: Float = 0f
        private set

    var panY: Float = 0f
        private set

    fun setTransform(newScale: Float, newPanX: Float, newPanY: Float) {
        scale = newScale.coerceIn(minScale, maxScale)
        panX = newPanX
        panY = newPanY
    }

    fun updatePan(deltaX: Float, deltaY: Float) {
        panX += deltaX
        panY += deltaY
    }

    fun updateZoom(zoomFactor: Float, focalX: Float, focalY: Float) {
        val oldScale = scale
        val targetScale = (scale * zoomFactor).coerceIn(minScale, maxScale)
        val actualFactor = targetScale / oldScale

        // Zoom relative to touch focal center
        panX = focalX - (focalX - panX) * actualFactor
        panY = focalY - (focalY - panY) * actualFactor
        scale = targetScale
    }

    fun reset() {
        scale = 1.0f
        panX = 0f
        panY = 0f
    }

    /**
     * Converts a point from screen viewport pixels to canvas coordinates.
     */
    fun screenToCanvasX(screenX: Float): Float = (screenX - panX) / scale

    fun screenToCanvasY(screenY: Float): Float = (screenY - panY) / scale

    /**
     * Converts a point from document canvas coordinates to screen viewport pixels.
     */
    fun canvasToScreenX(canvasX: Float): Float = (canvasX * scale) + panX

    fun canvasToScreenY(canvasY: Float): Float = (canvasY * scale) + panY
}
