package com.inknote.app.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.inknote.app.data.model.Notebook
import kotlinx.coroutines.flow.Flow

@Dao
interface NotebookDao {
    @Query("SELECT * FROM notebooks ORDER BY updatedAt DESC")
    fun getAllNotebooks(): Flow<List<Notebook>>

    @Query("SELECT * FROM notebooks WHERE folderId = :folderId ORDER BY updatedAt DESC")
    fun getNotebooksInFolder(folderId: String): Flow<List<Notebook>>

    @Query("SELECT * FROM notebooks WHERE folderId IS NULL ORDER BY updatedAt DESC")
    fun getRootNotebooks(): Flow<List<Notebook>>

    @Query("SELECT * FROM notebooks WHERE isFavorite = 1 ORDER BY updatedAt DESC")
    fun getFavoriteNotebooks(): Flow<List<Notebook>>

    @Query("SELECT * FROM notebooks WHERE title LIKE '%' || :query || '%' ORDER BY updatedAt DESC")
    fun searchNotebooks(query: String): Flow<List<Notebook>>

    @Query("SELECT * FROM notebooks WHERE id = :id")
    suspend fun getNotebookById(id: String): Notebook?

    @Query("SELECT * FROM notebooks WHERE id = :id")
    fun getNotebookByIdFlow(id: String): Flow<Notebook?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotebook(notebook: Notebook)

    @Update
    suspend fun updateNotebook(notebook: Notebook)

    @Delete
    suspend fun deleteNotebook(notebook: Notebook)

    @Query("UPDATE notebooks SET isFavorite = :isFavorite, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateFavorite(id: String, isFavorite: Boolean, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE notebooks SET title = :newTitle, updatedAt = :updatedAt WHERE id = :id")
    suspend fun renameNotebook(id: String, newTitle: String, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE notebooks SET folderId = :newFolderId, updatedAt = :updatedAt WHERE id = :id")
    suspend fun moveNotebook(id: String, newFolderId: String?, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE notebooks SET pageCount = :pageCount, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updatePageCount(id: String, pageCount: Int, updatedAt: Long = System.currentTimeMillis())
}
