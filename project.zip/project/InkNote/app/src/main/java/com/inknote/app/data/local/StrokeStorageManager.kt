package com.inknote.app.data.local

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.inknote.app.data.model.Stroke
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileReader
import java.io.FileWriter

class StrokeStorageManager(private val context: Context) {
    private val gson = Gson()
    private val listType = object : TypeToken<List<Stroke>>() {}.type

    private fun getFile(notebookId: String, pageId: String): File {
        val dir = File(context.filesDir, "documents/$notebookId")
        if (!dir.exists()) dir.mkdirs()
        return File(dir, "page_${pageId}.json")
    }

    suspend fun saveStrokes(notebookId: String, pageId: String, strokes: List<Stroke>): Boolean = withContext(Dispatchers.IO) {
        try {
            val target = getFile(notebookId, pageId)
            val tmp = File(target.parentFile, target.name + ".tmp")
            FileWriter(tmp).use { gson.toJson(strokes, listType, it) }
            if (tmp.exists()) {
                if (target.exists()) target.delete()
                tmp.renameTo(target)
            }
            true
        } catch (e: Exception) { false }
    }

    suspend fun loadStrokes(notebookId: String, pageId: String): List<Stroke> = withContext(Dispatchers.IO) {
        try {
            val target = getFile(notebookId, pageId)
            if (!target.exists()) return@withContext emptyList()
            FileReader(target).use { gson.fromJson(it, listType) ?: emptyList() }
        } catch (e: Exception) { emptyList() }
    }

    suspend fun deleteNotebookDir(notebookId: String) = withContext(Dispatchers.IO) {
        File(context.filesDir, "documents/$notebookId").deleteRecursively()
    }
}
