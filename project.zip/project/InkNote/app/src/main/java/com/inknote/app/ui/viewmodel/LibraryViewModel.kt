package com.inknote.app.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.inknote.app.data.model.Folder
import com.inknote.app.data.model.Notebook
import com.inknote.app.data.model.PaperColor
import com.inknote.app.data.model.PaperType
import com.inknote.app.data.repository.NotebookRepository
import com.inknote.app.engine.pdf.PdfImporter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class LibraryFilter {
    ALL,
    FAVORITES,
    PDFS
}

class LibraryViewModel(
    private val repository: NotebookRepository,
    private val pdfImporter: PdfImporter
) : ViewModel() {

    private val _currentFolderId = MutableStateFlow<String?>(null)
    val currentFolderId: StateFlow<String?> = _currentFolderId.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _activeFilter = MutableStateFlow(LibraryFilter.ALL)
    val activeFilter: StateFlow<LibraryFilter> = _activeFilter.asStateFlow()

    private val _isGridView = MutableStateFlow(true)
    val isGridView: StateFlow<Boolean> = _isGridView.asStateFlow()

    val folders: StateFlow<List<Folder>> = repository.rootFolders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notebooks: StateFlow<List<Notebook>> = combine(
        _currentFolderId,
        _searchQuery,
        _activeFilter
    ) { folderId, query, filter ->
        Triple(folderId, query, filter)
    }.flatMapLatest { (folderId, query, filter) ->
        if (query.isNotBlank()) {
            repository.searchNotebooks(query)
        } else if (filter == LibraryFilter.FAVORITES) {
            repository.favoriteNotebooks
        } else if (folderId != null) {
            repository.getNotebooksInFolder(folderId)
        } else {
            repository.allNotebooks
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setFolder(folderId: String?) {
        _currentFolderId.value = folderId
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setFilter(filter: LibraryFilter) {
        _activeFilter.value = filter
    }

    fun toggleViewMode() {
        _isGridView.value = !_isGridView.value
    }

    fun createNotebook(
        title: String,
        paperType: PaperType,
        paperColor: PaperColor,
        coverColorHex: String,
        onCreated: (String) -> Unit
    ) {
        viewModelScope.launch {
            val notebook = repository.createNotebook(
                title = title.ifBlank { "Untitled Notebook" },
                folderId = _currentFolderId.value,
                paperType = paperType,
                paperColor = paperColor,
                coverColorHex = coverColorHex
            )
            onCreated(notebook.id)
        }
    }

    fun importPdf(uri: Uri, onImported: (String) -> Unit) {
        viewModelScope.launch {
            val notebook = pdfImporter.importPdf(uri)
            if (notebook != null) {
                onImported(notebook.id)
            }
        }
    }

    fun createFolder(name: String) {
        viewModelScope.launch {
            repository.createFolder(name = name, parentId = _currentFolderId.value)
        }
    }

    fun toggleFavorite(notebook: Notebook) {
        viewModelScope.launch {
            repository.toggleFavorite(notebook)
        }
    }

    fun renameNotebook(notebook: Notebook, newTitle: String) {
        viewModelScope.launch {
            repository.renameNotebook(notebook.id, newTitle)
        }
    }

    fun duplicateNotebook(notebook: Notebook) {
        viewModelScope.launch {
            repository.duplicateNotebook(notebook)
        }
    }

    fun deleteNotebook(notebook: Notebook) {
        viewModelScope.launch {
            repository.deleteNotebook(notebook)
        }
    }

    fun deleteFolder(folder: Folder) {
        viewModelScope.launch {
            repository.deleteFolder(folder)
        }
    }
}
