package com.inknote.app.engine.drawing

import com.inknote.app.data.model.Stroke

sealed class DrawingAction {
    data class AddStroke(val stroke: Stroke) : DrawingAction()
    data class DeleteStrokes(val deletedStrokes: List<Stroke>) : DrawingAction()
    data class ClearAll(val previousStrokes: List<Stroke>) : DrawingAction()
}

/**
 * History manager maintaining undo and redo stacks with bounded memory footprint.
 */
class UndoRedoManager(private val maxHistory: Int = 50) {
    private val undoStack = ArrayDeque<DrawingAction>()
    private val redoStack = ArrayDeque<DrawingAction>()

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    fun recordAction(action: DrawingAction) {
        if (undoStack.size >= maxHistory) {
            undoStack.removeFirst()
        }
        undoStack.addLast(action)
        redoStack.clear() // Invalidate redo tree on new mutation
    }

    fun undo(currentStrokes: List<Stroke>): List<Stroke>? {
        if (!canUndo) return null
        val action = undoStack.removeLast()
        redoStack.addLast(action)

        return when (action) {
            is DrawingAction.AddStroke -> {
                currentStrokes.filter { it.id != action.stroke.id }
            }
            is DrawingAction.DeleteStrokes -> {
                currentStrokes + action.deletedStrokes
            }
            is DrawingAction.ClearAll -> {
                action.previousStrokes
            }
        }
    }

    fun redo(currentStrokes: List<Stroke>): List<Stroke>? {
        if (!canRedo) return null
        val action = redoStack.removeLast()
        undoStack.addLast(action)

        return when (action) {
            is DrawingAction.AddStroke -> {
                currentStrokes + action.stroke
            }
            is DrawingAction.DeleteStrokes -> {
                val deletedIds = action.deletedStrokes.map { it.id }.toSet()
                currentStrokes.filter { it.id !in deletedIds }
            }
            is DrawingAction.ClearAll -> {
                emptyList()
            }
        }
    }

    fun clear() {
        undoStack.clear()
        redoStack.clear()
    }
}
