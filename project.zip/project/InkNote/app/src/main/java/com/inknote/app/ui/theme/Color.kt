package com.inknote.app.ui.theme

import androidx.compose.ui.graphics.Color

val InkNavy = Color(0xFF1E293B)
val InkPrimary = Color(0xFF2C3E50)
val TerracottaAccent = Color(0xFFE06D53)
val TerracottaDark = Color(0xFFC85A42)
val SageGreen = Color(0xFF5B8266)
val MustardGold = Color(0xFFD99B26)

val WarmPaper = Color(0xFFFAF8F5)
val PaperSurface = Color(0xFFF4EFEB)
val PaperSurfaceVariant = Color(0xFFEAE3DA)
val CanvasGridLine = Color(0xFFD8D3C8)
val CanvasDot = Color(0xFFB5ADA0)

val CharcoalText = Color(0xFF2D3748)
val CharcoalMuted = Color(0xFF718096)

// Dark mode tablet palette
val DarkCanvasBg = Color(0xFF121820)
val DarkPaperSurface = Color(0xFF1A222C)
val DarkText = Color(0xFFE2E8F0)
val DarkTextMuted = Color(0xFF94A3B8)
val DarkGridLine = Color(0xFF2E3846)
