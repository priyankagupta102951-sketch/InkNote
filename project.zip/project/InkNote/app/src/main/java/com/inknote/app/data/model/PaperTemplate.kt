package com.inknote.app.data.model

enum class PaperType { BLANK, RULED, DOTTED, GRID }

enum class PaperColor(val hex: String, val darkHex: String, val displayName: String) {
    WARM_WHITE("#FAF8F5", "#242526", "Warm White"),
    CREAM("#F5EFEB", "#2C2A29", "Cream"),
    SOFT_YELLOW("#FFFDF0", "#2D2C22", "Soft Yellow"),
    MINT("#F0F7F4", "#202824", "Mint"),
    DARK_SLATE("#1E293B", "#0F172A", "Dark Slate")
}
