package com.inknote.app.engine.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.inknote.app.data.model.Notebook
import com.inknote.app.data.model.Page
import com.inknote.app.data.model.PaperColor
import com.inknote.app.data.model.PaperType
import com.inknote.app.data.model.Stroke
import com.inknote.app.data.model.ToolType
import com.inknote.app.data.repository.NotebookRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class PdfExporter(
    private val context: Context,
    private val repository: NotebookRepository
) {
    suspend fun exportNotebookToPdf(notebook: Notebook): File? {
        return withContext(Dispatchers.IO) {
            try {
                val exportDir = File(context.filesDir, "exports")
                if (!exportDir.exists()) exportDir.mkdirs()

                val sanitizedTitle = notebook.title.replace(Regex("[^a-zA-Z0-9_.-]"), "_")
                val outputFile = File(exportDir, "${sanitizedTitle}_annotated.pdf")

                val pdfDocument = PdfDocument()

                val db = com.inknote.app.data.local.InkNoteDatabase.getDatabase(context)
                val pages = db.pageDao().getPagesListForNotebook(notebook.id)

                var pdfRenderer: PdfRenderer? = null
                var pfd: ParcelFileDescriptor? = null

                if (notebook.pdfSourcePath != null && File(notebook.pdfSourcePath).exists()) {
                    pfd = ParcelFileDescriptor.open(File(notebook.pdfSourcePath), ParcelFileDescriptor.MODE_READ_ONLY)
                    pdfRenderer = PdfRenderer(pfd)
                }

                try {
                    for (page in pages) {
                        val pageWidth = page.width.toInt().coerceAtLeast(612)
                        val pageHeight = page.height.toInt().coerceAtLeast(792)

                        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, page.pageIndex + 1).create()
                        val pdfPage = pdfDocument.startPage(pageInfo)
                        val canvas = pdfPage.canvas

                        // 1. Draw base layer: PDF page or Paper template
                        if (page.pdfPageIndex != null && pdfRenderer != null && page.pdfPageIndex < pdfRenderer.pageCount) {
                            val rPage = pdfRenderer.openPage(page.pdfPageIndex)
                            val bmp = Bitmap.createBitmap(pageWidth, pageHeight, Bitmap.Config.ARGB_8888)
                            bmp.eraseColor(Color.WHITE)
                            rPage.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                            canvas.drawBitmap(bmp, 0f, 0f, null)
                            rPage.close()
                            bmp.recycle()
                        } else {
                            // Draw Paper Background
                            drawPaperBackground(canvas, pageWidth.toFloat(), pageHeight.toFloat(), page.paperType, page.paperColor)
                        }

                        // 2. Draw vector ink annotations on top
                        val strokes = repository.loadStrokes(notebook.id, page.id)
                        drawStrokes(canvas, strokes)

                        pdfDocument.finishPage(pdfPage)
                    }

                    FileOutputStream(outputFile).use { out ->
                        pdfDocument.writeTo(out)
                    }
                } finally {
                    pdfDocument.close()
                    pdfRenderer?.close()
                    pfd?.close()
                }

                outputFile
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }
    }

    private fun drawPaperBackground(
        canvas: android.graphics.Canvas,
        w: Float,
        h: Float,
        type: PaperType,
        color: PaperColor
    ) {
        val bgPaint = Paint().apply {
            this.color = android.graphics.Color.parseColor(color.hex)
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, w, h, bgPaint)

        val linePaint = Paint().apply {
            this.color = android.graphics.Color.parseColor("#D4CEBF")
            strokeWidth = 1.5f
            style = Paint.Style.STROKE
            isAntiAlias = true
        }

        when (type) {
            PaperType.BLANK -> {}
            PaperType.RULED -> {
                val lineSpacing = 48f
                var y = 96f
                while (y < h) {
                    canvas.drawLine(0f, y, w, y, linePaint)
                    y += lineSpacing
                }
            }
            PaperType.GRID -> {
                val gridSpacing = 40f
                var x = 0f
                while (x < w) {
                    canvas.drawLine(x, 0f, x, h, linePaint)
                    x += gridSpacing
                }
                var y = 0f
                while (y < h) {
                    canvas.drawLine(0f, y, w, y, linePaint)
                    y += gridSpacing
                }
            }
            PaperType.DOTTED -> {
                val dotPaint = Paint().apply {
                    this.color = android.graphics.Color.parseColor("#B0A99A")
                    style = Paint.Style.FILL
                    isAntiAlias = true
                }
                val dotSpacing = 36f
                var x = dotSpacing
                while (x < w) {
                    var y = dotSpacing
                    while (y < h) {
                        canvas.drawCircle(x, y, 2f, dotPaint)
                        y += dotSpacing
                    }
                    x += dotSpacing
                }
            }
        }
    }

    private fun drawStrokes(canvas: android.graphics.Canvas, strokes: List<Stroke>) {
        for (stroke in strokes) {
            if (stroke.points.size < 2) continue

            val paint = Paint().apply {
                isAntiAlias = true
                strokeCap = Paint.Cap.ROUND
                strokeJoin = Paint.Join.ROUND
                style = Paint.Style.STROKE
                strokeWidth = stroke.width
                color = runCatching { Color.parseColor(stroke.colorHex) }.getOrDefault(Color.BLACK)
            }

            if (stroke.toolType == ToolType.HIGHLIGHTER) {
                paint.alpha = (255 * 0.35f).toInt()
                paint.strokeCap = Paint.Cap.SQUARE
            } else if (stroke.toolType == ToolType.PENCIL) {
                paint.alpha = (255 * 0.75f).toInt()
            }

            val path = Path()
            val first = stroke.points.first()
            path.moveTo(first.x, first.y)

            for (i in 1 until stroke.points.size) {
                val p1 = stroke.points[i - 1]
                val p2 = stroke.points[i]
                val midX = (p1.x + p2.x) / 2f
                val midY = (p1.y + p2.y) / 2f
                path.quadTo(p1.x, p1.y, midX, midY)
            }
            val last = stroke.points.last()
            path.lineTo(last.x, last.y)

            canvas.drawPath(path, paint)
        }
    }
}
