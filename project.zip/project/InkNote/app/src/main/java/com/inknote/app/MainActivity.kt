package com.inknote.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.lifecycle.lifecycleScope
import com.inknote.app.data.model.Notebook
import com.inknote.app.data.model.Page
import com.inknote.app.data.model.Stroke
import com.inknote.app.ui.screens.EditorScreen
import com.inknote.app.ui.screens.LibraryScreen
import com.inknote.app.ui.theme.InkNoteTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = InkNoteApp.instance

        setContent {
            InkNoteTheme {
                var currentNotebookId by remember { mutableStateOf<String?>(null) }
                val notebooks by app.repository.allNotebooks.collectAsState(emptyList())

                if (currentNotebookId == null) {
                    LibraryScreen(
                        notebooks = notebooks,
                        onCreateNotebook = { title ->
                            lifecycleScope.launch {
                                val nb = app.repository.createNotebook(title)
                                currentNotebookId = nb.id
                            }
                        },
                        onImportPdf = { uri ->
                            lifecycleScope.launch {
                                val nb = app.pdfImporter.importPdf(uri)
                                if (nb != null) currentNotebookId = nb.id
                            }
                        },
                        onOpenNotebook = { currentNotebookId = it },
                        onDeleteNotebook = { nb -> lifecycleScope.launch { app.repository.deleteNotebook(nb) } }
                    )
                } else {
                    val activeId = currentNotebookId!!
                    val activeNb = notebooks.find { it.id == activeId }
                    val pages by app.repository.getPagesForNotebook(activeId).collectAsState(emptyList())
                    var strokes by remember { mutableStateOf<List<Stroke>>(emptyList()) }

                    LaunchedEffect(activeId, pages) {
                        pages.firstOrNull()?.let { p ->
                            strokes = app.repository.loadStrokes(activeId, p.id)
                        }
                    }

                    if (activeNb != null && pages.isNotEmpty()) {
                        EditorScreen(
                            notebook = activeNb,
                            pages = pages,
                            strokes = strokes,
                            onAddStroke = { s ->
                                strokes = strokes + s
                                lifecycleScope.launch { app.repository.saveStrokes(activeId, s.pageId, strokes) }
                            },
                            onEraseStrokes = { erased ->
                                val ids = erased.map { it.id }.toSet()
                                strokes = strokes.filter { it.id !in ids }
                                pages.firstOrNull()?.let { p ->
                                    lifecycleScope.launch { app.repository.saveStrokes(activeId, p.id, strokes) }
                                }
                            },
                            onAddPage = {
                                lifecycleScope.launch { app.repository.addPage(activeId, pages.size - 1, activeNb.defaultPaperType, activeNb.defaultPaperColor) }
                            },
                            onExportPdf = {
                                lifecycleScope.launch { app.pdfExporter.exportNotebookToPdf(activeNb) }
                            },
                            onBack = { currentNotebookId = null }
                        )
                    }
                }
            }
        }
    }
}
