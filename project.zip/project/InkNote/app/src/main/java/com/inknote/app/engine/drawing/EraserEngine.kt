package com.inknote.app.engine.drawing

import com.inknote.app.data.model.Stroke

/**
 * High-performance hit-testing engine for stroke eraser functionality.
 * Evaluates bounding box candidates first, then performs exact segment distance math.
 */
class EraserEngine {

    /**
     * Returns a list of strokes that intersect with the eraser touch path point (px, py)
     * within the specified eraser radius.
     */
    fun findStrokesToErase(
        strokes: List<Stroke>,
        px: Float,
        py: Float,
        eraserRadius: Float = 24f
    ): List<Stroke> {
        val hitStrokes = mutableListOf<Stroke>()
        for (stroke in strokes) {
            if (stroke.isPointNearStroke(px, py, threshold = eraserRadius + (stroke.width / 2f))) {
                hitStrokes.add(stroke)
            }
        }
        return hitStrokes
    }

    /**
     * Batch stroke eraser along an active eraser drag trajectory.
     */
    fun findStrokesAlongPath(
        strokes: List<Stroke>,
        eraserPoints: List<Pair<Float, Float>>,
        eraserRadius: Float = 24f
    ): Set<String> {
        val erasedStrokeIds = mutableSetOf<String>()
        for (stroke in strokes) {
            for ((ex, ey) in eraserPoints) {
                if (stroke.isPointNearStroke(ex, ey, threshold = eraserRadius + (stroke.width / 2f))) {
                    erasedStrokeIds.add(stroke.id)
                    break
                }
            }
        }
        return erasedStrokeIds
    }
}
