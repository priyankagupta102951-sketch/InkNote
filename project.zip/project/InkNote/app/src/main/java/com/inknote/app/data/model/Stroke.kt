package com.inknote.app.data.model

import java.util.UUID

enum class ToolType { PEN, PENCIL, HIGHLIGHTER, ERASER }

data class StrokePoint(
    val x: Float,
    val y: Float,
    val pressure: Float = 1.0f,
    val timestamp: Long = System.currentTimeMillis()
)

data class Stroke(
    val id: String = UUID.randomUUID().toString(),
    val pageId: String,
    val points: List<StrokePoint>,
    val colorHex: String,
    val width: Float,
    val toolType: ToolType,
    val alpha: Float = if (toolType == ToolType.HIGHLIGHTER) 0.35f else if (toolType == ToolType.PENCIL) 0.75f else 1.0f,
    val minX: Float = points.minOfOrNull { it.x } ?: 0f,
    val minY: Float = points.minOfOrNull { it.y } ?: 0f,
    val maxX: Float = points.maxOfOrNull { it.x } ?: 0f,
    val maxY: Float = points.maxOfOrNull { it.y } ?: 0f
) {
    fun isPointNearStroke(px: Float, py: Float, threshold: Float = width + 12f): Boolean {
        if (px < minX - threshold || px > maxX + threshold || py < minY - threshold || py > maxY + threshold) return false
        val thresholdSq = threshold * threshold
        for (i in 0 until points.size - 1) {
            val p1 = points[i]
            val p2 = points[i + 1]
            val dx = p2.x - p1.x
            val dy = p2.y - p1.y
            val t = if (dx == 0f && dy == 0f) 0f else (((px - p1.x) * dx + (py - p1.y) * dy) / (dx * dx + dy * dy)).coerceIn(0f, 1f)
            val projX = p1.x + t * dx
            val projY = p1.y + t * dy
            val distSq = (px - projX) * (px - projX) + (py - projY) * (py - projY)
            if (distSq <= thresholdSq) return true
        }
        return false
    }
}
