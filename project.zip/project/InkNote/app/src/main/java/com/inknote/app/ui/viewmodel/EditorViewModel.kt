package com.inknote.app.ui.viewmodel

import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.inknote.app.data.model.Notebook
import com.inknote.app.data.model.Page
import com.inknote.app.data.model.PaperColor
import com.inknote.app.data.model.PaperType
import com.inknote.app.data.model.SaveStatus
import com.inknote.app.data.model.Stroke
import com.inknote.app.data.model.ToolType
import com.inknote.app.data.repository.NotebookRepository
import com.inknote.app.engine.drawing.DrawingAction
import com.inknote.app.engine.drawing.EraserEngine
import com.inknote.app.engine.drawing.TransformManager
import com.inknote.app.engine.drawing.UndoRedoManager
import com.inknote.app.engine.pdf.PdfExporter
import com.inknote.app.engine.pdf.PdfPageRenderer
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

class EditorViewModel(
    val notebookId: String,
    private val repository: NotebookRepository,
    private val pdfExporter: PdfExporter
) : ViewModel() {

    private val _notebook = MutableStateFlow<Notebook?>(null)
    val notebook: StateFlow<Notebook?> = _notebook.asStateFlow()

    private val _pages = MutableStateFlow<List<Page>>(emptyList())
    val pages: StateFlow<List<Page>> = _pages.asStateFlow()

    private val _currentPageIndex = MutableStateFlow(0)
    val currentPageIndex: StateFlow<Int> = _currentPageIndex.asStateFlow()

    private val _strokes = MutableStateFlow<List<Stroke>>(emptyList())
    val strokes: StateFlow<List<Stroke>> = _strokes.asStateFlow()

    private val _saveStatus = MutableStateFlow(SaveStatus.SAVED)
    val saveStatus: StateFlow<SaveStatus> = _saveStatus.asStateFlow()

    private val _currentTool = MutableStateFlow(ToolType.PEN)
    val currentTool: StateFlow<ToolType> = _currentTool.asStateFlow()

    private val _currentColorHex = MutableStateFlow("#1E293B")
    val currentColorHex: StateFlow<String> = _currentColorHex.asStateFlow()

    private val _currentStrokeWidth = MutableStateFlow(4.0f)
    val currentStrokeWidth: StateFlow<Float> = _currentStrokeWidth.asStateFlow()

    private val _canUndo = MutableStateFlow(false)
    val canUndo: StateFlow<Boolean> = _canUndo.asStateFlow()

    private val _canRedo = MutableStateFlow(false)
    val canRedo: StateFlow<Boolean> = _canRedo.asStateFlow()

    private val _pdfPageBitmap = MutableStateFlow<Bitmap?>(null)
    val pdfPageBitmap: StateFlow<Bitmap?> = _pdfPageBitmap.asStateFlow()

    private val _exportedPdf = MutableStateFlow<File?>(null)
    val exportedPdf: StateFlow<File?> = _exportedPdf.asStateFlow()

    val transformManager = TransformManager()
    val eraserEngine = EraserEngine()
    private val undoRedoManager = UndoRedoManager()

    private var pdfRenderer: PdfPageRenderer? = null
    private var autosaveJob: Job? = null

    init {
        loadNotebook()
    }

    private fun loadNotebook() {
        viewModelScope.launch {
            val nb = repository.getNotebook(notebookId)
            _notebook.value = nb

            if (nb?.pdfSourcePath != null && File(nb.pdfSourcePath).exists()) {
                pdfRenderer = PdfPageRenderer(File(nb.pdfSourcePath))
            }

            repository.getPagesForNotebook(notebookId).collect { pagesList ->
                _pages.value = pagesList
                if (pagesList.isNotEmpty()) {
                    val safeIndex = _currentPageIndex.value.coerceIn(0, pagesList.size - 1)
                    _currentPageIndex.value = safeIndex
                    loadPageData(pagesList[safeIndex])
                }
            }
        }
    }

    private fun loadPageData(page: Page) {
        viewModelScope.launch {
            _saveStatus.value = SaveStatus.SAVING
            val loadedStrokes = repository.loadStrokes(notebookId, page.id)
            _strokes.value = loadedStrokes
            undoRedoManager.clear()
            updateUndoRedoState()
            _saveStatus.value = SaveStatus.SAVED

            if (page.pdfPageIndex != null && pdfRenderer != null) {
                val bmp = pdfRenderer?.renderPage(page.pdfPageIndex, page.width.toInt(), page.height.toInt())
                _pdfPageBitmap.value = bmp
            } else {
                _pdfPageBitmap.value = null
            }
        }
    }

    fun selectPage(index: Int) {
        val pagesList = _pages.value
        if (index in pagesList.indices && index != _currentPageIndex.value) {
            saveCurrentPageImmediate()
            _currentPageIndex.value = index
            loadPageData(pagesList[index])
        }
    }

    fun addStroke(stroke: Stroke) {
        val updated = _strokes.value + stroke
        _strokes.value = updated
        undoRedoManager.recordAction(DrawingAction.AddStroke(stroke))
        updateUndoRedoState()
        triggerAutosave()
    }

    fun eraseStrokes(erasedStrokes: List<Stroke>) {
        val erasedIds = erasedStrokes.map { it.id }.toSet()
        val updated = _strokes.value.filter { it.id !in erasedIds }
        _strokes.value = updated
        undoRedoManager.recordAction(DrawingAction.DeleteStrokes(erasedStrokes))
        updateUndoRedoState()
        triggerAutosave()
    }

    fun undo() {
        val updated = undoRedoManager.undo(_strokes.value)
        if (updated != null) {
            _strokes.value = updated
            updateUndoRedoState()
            triggerAutosave()
        }
    }

    fun redo() {
        val updated = undoRedoManager.redo(_strokes.value)
        if (updated != null) {
            _strokes.value = updated
            updateUndoRedoState()
            triggerAutosave()
        }
    }

    private fun updateUndoRedoState() {
        _canUndo.value = undoRedoManager.canUndo
        _canRedo.value = undoRedoManager.canRedo
    }

    private fun triggerAutosave() {
        _saveStatus.value = SaveStatus.UNSAVED
        autosaveJob?.cancel()
        autosaveJob = viewModelScope.launch {
            delay(1000)
            saveCurrentPageImmediate()
        }
    }

    fun saveCurrentPageImmediate() {
        val pagesList = _pages.value
        val index = _currentPageIndex.value
        if (index in pagesList.indices) {
            val page = pagesList[index]
            viewModelScope.launch {
                _saveStatus.value = SaveStatus.SAVING
                val success = repository.saveStrokes(notebookId, page.id, _strokes.value)
                _saveStatus.value = if (success) SaveStatus.SAVED else SaveStatus.ERROR
            }
        }
    }

    fun setTool(tool: ToolType) {
        _currentTool.value = tool
        if (tool == ToolType.HIGHLIGHTER) {
            _currentStrokeWidth.value = 24.0f
        } else if (tool == ToolType.PEN) {
            _currentStrokeWidth.value = 4.0f
        } else if (tool == ToolType.PENCIL) {
            _currentStrokeWidth.value = 3.0f
        } else if (tool == ToolType.ERASER) {
            _currentStrokeWidth.value = 20.0f
        }
    }

    fun setColor(colorHex: String) {
        _currentColorHex.value = colorHex
    }

    fun setStrokeWidth(width: Float) {
        _currentStrokeWidth.value = width
    }

    fun addNewPage(paperType: PaperType? = null, paperColor: PaperColor? = null) {
        val nb = _notebook.value ?: return
        viewModelScope.launch {
            saveCurrentPageImmediate()
            val newPage = repository.addPage(
                notebookId = notebookId,
                afterIndex = _currentPageIndex.value,
                paperType = paperType ?: nb.defaultPaperType,
                paperColor = paperColor ?: nb.defaultPaperColor
            )
            _currentPageIndex.value = newPage.pageIndex
        }
    }

    fun deleteCurrentPage() {
        val pagesList = _pages.value
        val index = _currentPageIndex.value
        if (pagesList.size > 1 && index in pagesList.indices) {
            viewModelScope.launch {
                val pageToDelete = pagesList[index]
                val success = repository.deletePage(notebookId, pageToDelete)
                if (success) {
                    _currentPageIndex.value = (index - 1).coerceAtLeast(0)
                }
            }
        }
    }

    fun duplicatePage(page: Page) {
        val nb = _notebook.value ?: return
        viewModelScope.launch {
            saveCurrentPageImmediate()
            val newPage = repository.addPage(
                notebookId = notebookId,
                afterIndex = page.pageIndex,
                paperType = page.paperType,
                paperColor = page.paperColor
            )
            val strokesToCopy = repository.loadStrokes(notebookId, page.id)
            repository.saveStrokes(notebookId, newPage.id, strokesToCopy)
            _currentPageIndex.value = newPage.pageIndex
        }
    }

    fun updatePageTemplate(paperType: PaperType, paperColor: PaperColor) {
        val pagesList = _pages.value
        val index = _currentPageIndex.value
        if (index in pagesList.indices) {
            val page = pagesList[index]
            viewModelScope.launch {
                repository.updatePageTemplate(page, paperType, paperColor)
            }
        }
    }

    fun exportToPdf(onComplete: (File?) -> Unit) {
        val nb = _notebook.value ?: return
        viewModelScope.launch {
            saveCurrentPageImmediate()
            val exportedFile = pdfExporter.exportNotebookToPdf(nb)
            _exportedPdf.value = exportedFile
            onComplete(exportedFile)
        }
    }

    override fun onCleared() {
        super.onCleared()
        saveCurrentPageImmediate()
        pdfRenderer?.close()
    }
}
