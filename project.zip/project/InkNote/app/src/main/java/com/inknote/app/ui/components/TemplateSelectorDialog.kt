package com.inknote.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.inknote.app.data.model.PaperColor
import com.inknote.app.data.model.PaperType
import com.inknote.app.ui.theme.TerracottaAccent

@Composable
fun TemplateSelectorDialog(
    initialPaperType: PaperType = PaperType.RULED,
    initialPaperColor: PaperColor = PaperColor.WARM_WHITE,
    onDismiss: () -> Unit,
    onConfirm: (PaperType, PaperColor) -> Unit
) {
    var selectedType by remember { mutableStateOf(initialPaperType) }
    var selectedColor by remember { mutableStateOf(initialPaperColor) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Choose Paper Template", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column {
                Text("Paper Style", style = MaterialTheme.typography.titleMedium, color = Color(0xFF2D3748))
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PaperType.values().forEach { type ->
                        val isSelected = type == selectedType
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) TerracottaAccent.copy(alpha = 0.15f) else Color(0xFFF4EFEB))
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) TerracottaAccent else Color(0xFFD4CEBF),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable { selectedType = type },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = type.name.lowercase().replaceFirstChar { it.uppercase() },
                                fontSize = 13.sp,
                                color = if (isSelected) TerracottaAccent else Color(0xFF2D3748)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
                Text("Paper Tone", style = MaterialTheme.typography.titleMedium, color = Color(0xFF2D3748))
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    PaperColor.values().forEach { paperColor ->
                        val isSelected = paperColor == selectedColor
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.clickable { selectedColor = paperColor }
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(android.graphics.Color.parseColor(paperColor.hex)))
                                    .border(
                                        width = if (isSelected) 3.dp else 1.dp,
                                        color = if (isSelected) TerracottaAccent else Color(0xFFB0A99F),
                                        shape = CircleShape
                                    )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = paperColor.displayName,
                                fontSize = 10.sp,
                                color = if (isSelected) TerracottaAccent else Color(0xFF718096)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(selectedType, selectedColor) },
                colors = ButtonDefaults.buttonColors(containerColor = TerracottaAccent)
            ) {
                Text("Apply Template")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
