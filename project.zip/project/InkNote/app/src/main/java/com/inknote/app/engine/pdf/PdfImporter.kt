package com.inknote.app.engine.pdf

import android.content.Context
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.inknote.app.data.model.Notebook
import com.inknote.app.data.model.Page
import com.inknote.app.data.model.PaperColor
import com.inknote.app.data.model.PaperType
import com.inknote.app.data.repository.NotebookRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

class PdfImporter(
    private val context: Context,
    private val repository: NotebookRepository
) {
    suspend fun importPdf(uri: Uri, title: String? = null): Notebook? {
        return withContext(Dispatchers.IO) {
            try {
                val notebookId = UUID.randomUUID().toString()
                val notebookDir = File(context.filesDir, "documents/$notebookId")
                notebookDir.mkdirs()

                val localPdfFile = File(notebookDir, "source.pdf")

                // Stream copy from content resolver
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(localPdfFile).use { output ->
                        input.copyTo(output)
                    }
                } ?: return@withContext null

                // Read page count and dimensions
                var pageCount = 1
                val pagesList = mutableListOf<Page>()

                ParcelFileDescriptor.open(localPdfFile, ParcelFileDescriptor.MODE_READ_ONLY)?.use { pfd ->
                    PdfRenderer(pfd).use { renderer ->
                        pageCount = renderer.pageCount
                        for (i in 0 until pageCount) {
                            val page = renderer.openPage(i)
                            val w = page.width.toFloat()
                            val h = page.height.toFloat()
                            page.close()

                            pagesList.add(
                                Page(
                                    id = UUID.randomUUID().toString(),
                                    notebookId = notebookId,
                                    pageIndex = i,
                                    paperType = PaperType.BLANK,
                                    paperColor = PaperColor.WARM_WHITE,
                                    pdfPageIndex = i,
                                    width = if (w > 0) w else 1440f,
                                    height = if (h > 0) h else 1920f
                                )
                            )
                        }
                    }
                }

                val docTitle = title ?: localPdfFile.nameWithoutExtension.ifEmpty { "Imported PDF" }
                val notebook = repository.createNotebook(
                    title = docTitle,
                    paperType = PaperType.BLANK,
                    paperColor = PaperColor.WARM_WHITE,
                    coverColorHex = "#C0392B", // Signature PDF Red cover
                    initialPages = 0,
                    pdfPath = localPdfFile.absolutePath
                )

                // Insert real pages
                val db = com.inknote.app.data.local.InkNoteDatabase.getDatabase(context)
                db.pageDao().insertPages(pagesList.map { it.copy(notebookId = notebook.id) })
                db.notebookDao().updatePageCount(notebook.id, pagesList.size)

                notebook.copy(pageCount = pagesList.size)
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }
    }
}
