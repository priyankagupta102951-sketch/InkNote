package com.inknote.app.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "folders")
data class Folder(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val parentId: String? = null,
    val colorHex: String = "#5B8266",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "notebooks")
data class Notebook(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val title: String,
    val folderId: String? = null,
    val coverColorHex: String = "#2C3E50",
    val defaultPaperType: PaperType = PaperType.RULED,
    val defaultPaperColor: PaperColor = PaperColor.WARM_WHITE,
    val pageCount: Int = 1,
    val isFavorite: Boolean = false,
    val pdfSourcePath: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "pages")
data class Page(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val notebookId: String,
    val pageIndex: Int,
    val paperType: PaperType = PaperType.RULED,
    val paperColor: PaperColor = PaperColor.WARM_WHITE,
    val pdfPageIndex: Int? = null,
    val width: Float = 1440f,
    val height: Float = 1920f,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

enum class SaveStatus { SAVED, SAVING, UNSAVED, ERROR }
