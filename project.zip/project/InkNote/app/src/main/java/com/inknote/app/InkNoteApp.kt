package com.inknote.app

import android.app.Application
import com.inknote.app.data.local.InkNoteDatabase
import com.inknote.app.data.local.StrokeStorageManager
import com.inknote.app.data.repository.NotebookRepository
import com.inknote.app.engine.pdf.PdfExporter
import com.inknote.app.engine.pdf.PdfImporter

class InkNoteApp : Application() {
    lateinit var repository: NotebookRepository; private set
    lateinit var pdfImporter: PdfImporter; private set
    lateinit var pdfExporter: PdfExporter; private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        val db = InkNoteDatabase.getDatabase(this)
        val storage = StrokeStorageManager(this)
        repository = NotebookRepository(db, storage)
        pdfImporter = PdfImporter(this, repository)
        pdfExporter = PdfExporter(this, repository)
    }

    companion object { lateinit var instance: InkNoteApp; private set }
}
