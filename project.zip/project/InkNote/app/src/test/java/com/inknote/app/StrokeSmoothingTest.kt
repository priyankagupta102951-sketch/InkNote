package com.inknote.app

import com.inknote.app.data.model.StrokePoint
import com.inknote.app.data.model.ToolType
import com.inknote.app.engine.drawing.StrokeSmoother
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class StrokeSmoothingTest {

    @Test
    fun testJitterFilterDiscardsSubpixelMovements() {
        val p1 = StrokePoint(100.0f, 100.0f)

        // Point within 1.0px (subpixel jitter) should be discarded
        val shouldAddJitter = StrokeSmoother.shouldAddPoint(p1, 100.5f, 100.5f)
        assertFalse("Subpixel motion should be filtered out", shouldAddJitter)

        // Point with distance >= 2.0px should be kept
        val shouldAddRealPoint = StrokeSmoother.shouldAddPoint(p1, 103.0f, 104.0f)
        assertTrue("Substantial stroke movement should be retained", shouldAddRealPoint)
    }

    @Test
    fun testPressureDynamicallyExpandsPenWidth() {
        val baseWidth = 4.0f

        val lightPressureWidth = StrokeSmoother.calculateDynamicWidth(ToolType.PEN, baseWidth, pressure = 0.2f)
        val heavyPressureWidth = StrokeSmoother.calculateDynamicWidth(ToolType.PEN, baseWidth, pressure = 1.4f)

        assertTrue("Heavy pressure must yield a wider stroke than light pressure", heavyPressureWidth > lightPressureWidth)
    }

    @Test
    fun testHighlighterMaintainsConsistentChiselWidth() {
        val baseWidth = 24.0f
        val w1 = StrokeSmoother.calculateDynamicWidth(ToolType.HIGHLIGHTER, baseWidth, pressure = 0.3f)
        val w2 = StrokeSmoother.calculateDynamicWidth(ToolType.HIGHLIGHTER, baseWidth, pressure = 1.5f)

        assertEquals("Highlighters must have uniform stroke width regardless of pressure", w1, w2, 0.001f)
    }

    @Test
    fun testMidpointCalculationForQuadraticBezier() {
        val points = listOf(
            StrokePoint(0f, 0f),
            StrokePoint(10f, 10f),
            StrokePoint(20f, 0f)
        )

        val midpoints = StrokeSmoother.calculateMidpoints(points)
        assertEquals(2, midpoints.size)
        assertEquals(5f, midpoints[0].first, 0.001f)
        assertEquals(5f, midpoints[0].second, 0.001f)
        assertEquals(15f, midpoints[1].first, 0.001f)
        assertEquals(5f, midpoints[1].second, 0.001f)
    }
}
