package com.inknote.app

import com.inknote.app.data.model.Stroke
import com.inknote.app.data.model.StrokePoint
import com.inknote.app.data.model.ToolType
import com.inknote.app.engine.drawing.DrawingAction
import com.inknote.app.engine.drawing.UndoRedoManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UndoRedoManagerTest {

    private fun createDummyStroke(id: String): Stroke {
        return Stroke(
            id = id,
            pageId = "page-1",
            points = listOf(StrokePoint(0f, 0f), StrokePoint(10f, 10f)),
            colorHex = "#000000",
            width = 2f,
            toolType = ToolType.PEN
        )
    }

    @Test
    fun testAddStrokeUndoAndRedo() {
        val undoRedo = UndoRedoManager()
        val s1 = createDummyStroke("s1")

        assertFalse(undoRedo.canUndo)
        assertFalse(undoRedo.canRedo)

        undoRedo.recordAction(DrawingAction.AddStroke(s1))
        assertTrue(undoRedo.canUndo)
        assertFalse(undoRedo.canRedo)

        val currentList = listOf(s1)
        val afterUndo = undoRedo.undo(currentList)
        assertEquals(0, afterUndo?.size)
        assertFalse(undoRedo.canUndo)
        assertTrue(undoRedo.canRedo)

        val afterRedo = undoRedo.redo(afterUndo ?: emptyList())
        assertEquals(1, afterRedo?.size)
        assertEquals("s1", afterRedo?.get(0)?.id)
        assertTrue(undoRedo.canUndo)
        assertFalse(undoRedo.canRedo)
    }

    @Test
    fun testDeleteStrokeUndoAndRedo() {
        val undoRedo = UndoRedoManager()
        val s1 = createDummyStroke("s1")
        val s2 = createDummyStroke("s2")

        val initialList = listOf(s1, s2)
        // Simulate deleting s1
        undoRedo.recordAction(DrawingAction.DeleteStrokes(listOf(s1)))

        val currentList = listOf(s2)
        val restored = undoRedo.undo(currentList)
        assertEquals(2, restored?.size)

        val reErased = undoRedo.redo(restored ?: emptyList())
        assertEquals(1, reErased?.size)
        assertEquals("s2", reErased?.get(0)?.id)
    }
}
