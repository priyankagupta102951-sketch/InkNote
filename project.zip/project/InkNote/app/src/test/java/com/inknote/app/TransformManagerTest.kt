package com.inknote.app

import com.inknote.app.engine.drawing.TransformManager
import org.junit.Assert.assertEquals
import org.junit.Test

class TransformManagerTest {

    @Test
    fun testDefaultTransformationIsIdentity() {
        val tm = TransformManager()
        assertEquals(1.0f, tm.scale, 0.001f)
        assertEquals(0f, tm.panX, 0.001f)
        assertEquals(0f, tm.panY, 0.001f)

        // Screen coords match canvas coords at 1.0x with 0 pan
        assertEquals(250f, tm.screenToCanvasX(250f), 0.001f)
        assertEquals(500f, tm.screenToCanvasY(500f), 0.001f)
    }

    @Test
    fun testZoomAndPanCoordinateMapping() {
        val tm = TransformManager()
        tm.setTransform(newScale = 2.0f, newPanX = 100f, newPanY = 50f)

        // Test canvasToScreen: (canvas * 2.0) + pan
        val screenX = tm.canvasToScreenX(50f) // (50 * 2) + 100 = 200
        val screenY = tm.canvasToScreenY(100f) // (100 * 2) + 50 = 250
        assertEquals(200f, screenX, 0.001f)
        assertEquals(250f, screenY, 0.001f)

        // Test screenToCanvas (reverse mapping): (screen - pan) / scale
        assertEquals(50f, tm.screenToCanvasX(screenX), 0.001f)
        assertEquals(100f, tm.screenToCanvasY(screenY), 0.001f)
    }

    @Test
    fun testScaleClampingWithinBounds() {
        val tm = TransformManager(minScale = 0.5f, maxScale = 4.0f)

        tm.setTransform(newScale = 10.0f, newPanX = 0f, newPanY = 0f)
        assertEquals(4.0f, tm.scale, 0.001f)

        tm.setTransform(newScale = 0.1f, newPanX = 0f, newPanY = 0f)
        assertEquals(0.5f, tm.scale, 0.001f)
    }
}
