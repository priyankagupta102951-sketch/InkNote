package com.inknote.app

import com.inknote.app.data.model.Stroke
import com.inknote.app.data.model.StrokePoint
import com.inknote.app.data.model.ToolType
import com.inknote.app.engine.drawing.EraserEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EraserIntersectionTest {

    private val testStroke = Stroke(
        id = "stroke-1",
        pageId = "page-1",
        points = listOf(
            StrokePoint(100f, 100f),
            StrokePoint(200f, 100f),
            StrokePoint(300f, 100f)
        ),
        colorHex = "#1E293B",
        width = 4f,
        toolType = ToolType.PEN
    )

    private val eraserEngine = EraserEngine()

    @Test
    fun testPointNearStrokeHitsDirectly() {
        // Point (150, 102) is 2px away from line segment (100,100)-(200,100)
        assertTrue(testStroke.isPointNearStroke(150f, 102f, threshold = 10f))
    }

    @Test
    fun testPointFarFromStrokeMisses() {
        // Point (150, 250) is 150px away
        assertFalse(testStroke.isPointNearStroke(150f, 250f, threshold = 10f))
    }

    @Test
    fun testEraserEngineFindsCorrectHitStroke() {
        val strokeList = listOf(testStroke)
        val hits = eraserEngine.findStrokesToErase(strokeList, px = 250f, py = 105f, eraserRadius = 15f)

        assertEquals(1, hits.size)
        assertEquals("stroke-1", hits[0].id)
    }

    @Test
    fun testEraserEngineIgnoresNonIntersectingStrokes() {
        val strokeList = listOf(testStroke)
        val hits = eraserEngine.findStrokesToErase(strokeList, px = 50f, py = 50f, eraserRadius = 10f)

        assertTrue(hits.isEmpty())
    }
}
